﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string fees = "";
            double shapping_fees = 0;


            if (comboBox1.SelectedIndex <= -1) { MessageBox.Show("please select any count"); }
             if (comboBox2.SelectedIndex <= -1) { MessageBox.Show("please select any bag"); }
             if (comboBox3.SelectedIndex <= -1) { MessageBox.Show("please select any shapping type"); }
            else
            {
                string cb1 = comboBox1.SelectedItem.ToString();
                string cb2 = comboBox2.SelectedItem.ToString();
                string cb3 = comboBox3.SelectedItem.ToString();

                if (cb3 == "overnight")
                {
                    fees = "10%";
                    shapping_fees = (200 * Convert.ToInt32(cb1))+ (200 * (0.1));
                }
                else if (cb3 == "three day")
                {
                    fees = "7%";
                    shapping_fees = (200 * Convert.ToInt32(cb1)) + (200 * (0.07));
                }
                else if (cb3 == "standard")
                {
                    shapping_fees = (200 * Convert.ToInt32(cb1)) + (200 * (0.05));
                    fees = "5%";
                    
                }
             
                MessageBox.Show("bag : " + cb2 + "\n" +
                    "count : " + cb1 + "\n" +
                    "shapping tpye : " + cb3 + "\n" +
                    "shapping fees : " + fees + "\n" +
                    "toatel cost : " + shapping_fees
                    );
            }
 

          
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
