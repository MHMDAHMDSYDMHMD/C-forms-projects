﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string FName = textBox2.Text;
            string LName = textBox3.Text;
            string age = textBox4.Text;
            string job = textBox5.Text;
            string postion = "";
            if (radioButton1.Checked == true) {
                postion = "Instructor";
            }
            else if (radioButton2.Checked == true)
            {
                postion = "Student";
            }
            else {
               // MessageBox.Show("Please check your postion!");
            }
            if (name == null || name == "" || FName == null || FName == "" || LName == null || LName == "" || age == null || age == "" || job == null || job == "" || postion == null || postion == "")
            {
                MessageBox.Show("Please check your data!");
            }
            else {
                string[] Data = { name, FName, LName, age, job, postion };
                dataGridView1.Rows.Add(Data);
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //1st Way
            dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
            //2nd Way
            int NumberOfSelectRow = dataGridView1.SelectedRows.Count;
            if(NumberOfSelectRow > 0)
            foreach (DataGridViewRow Row in dataGridView1.SelectedRows)
            {
                //1st Way
                dataGridView1.Rows.RemoveAt(Row.Index);
                //2nd Way
                dataGridView1.Rows.Remove(Row);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                MessageBox.Show("ID: " + dataGridView1.SelectedCells[0].Value.ToString()
                + "\nFirst Name: " + dataGridView1.SelectedCells[1].Value.ToString()
                 + "\n Last Name: " + dataGridView1.SelectedCells[2].Value.ToString()
                  + "\n Age: " + dataGridView1.SelectedCells[3].Value.ToString()
                   + "\n Job: " + dataGridView1.SelectedCells[4].Value.ToString()
                    + "\n Postion: " + dataGridView1.SelectedCells[5].Value.ToString()
                    );
            }
            else {
                MessageBox.Show("Please select at least 1 Row");
            }
        }
    }
}
