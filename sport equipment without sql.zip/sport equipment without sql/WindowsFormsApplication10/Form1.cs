﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Member = "";
            decimal Quantity = 0;
            decimal Total_Price = 0;
           decimal Amount1 = numericUpDown1.Value;
           Quantity += Amount1;
            Amount1 *=200;
           decimal Amount2 =  numericUpDown2.Value;
           Quantity += Amount2;
           Amount2 *= 50;
           decimal Amount3 = numericUpDown3.Value;
           Quantity += Amount3;
           Amount3 *= 40;
           decimal Amount4 = numericUpDown4.Value;
           Quantity += Amount4;
           Amount4 *= 100;
           Total_Price = Amount1 + Amount2 + Amount3 + Amount4;
            if (radioButton1.Checked == false && radioButton2.Checked == false || numericUpDown1 == null || numericUpDown2 == null || numericUpDown3 == null || numericUpDown4 == null)
            {
                MessageBox.Show("Please check your data!");
            }
            else {
                if (radioButton1.Checked)
                {
                    Member = "Basic Member"; 
                }
                else if (radioButton2.Checked)
                {
                    Member = "Subsidiary Member";
                }
                else { }
                MessageBox.Show("Member: " + Member + "\nQuantity: " + Quantity + "\nTotal Price: "+Total_Price);
            }
        }
    }
}
