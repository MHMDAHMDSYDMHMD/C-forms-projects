﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            decimal amount = 0;
            decimal TextBox1 = numericUpDown1.Value;
                amount = TextBox1;
                TextBox1 *= 140;
            decimal TextBox2 = numericUpDown2.Value;
                amount += TextBox2;
                TextBox2 *= 300;
            decimal TextBox3 = numericUpDown3.Value;
                amount += TextBox3;
                TextBox3 *= 200;
            decimal TextBox4 = numericUpDown4.Value;
                amount += TextBox4;
                TextBox4 *= 250;

            decimal Total_Price = TextBox1 + TextBox2 + TextBox3 + TextBox4;
            string Price = Total_Price.ToString("#,##0.00");
            string WhichMember = "";
            if (radioButton1.Checked == true)
            {
                WhichMember = "Basic Member";
            }
             if (radioButton2.Checked == true)
             {
                 WhichMember = "Subsidiary Member";
             }
             if (radioButton1.Checked == false && radioButton2.Checked == false)
             {
                 MessageBox.Show("Select your Memeber Type!");
             }
             else
             {
                 MessageBox.Show("Member Type: " + WhichMember + "\nAmount: " + amount + "\nTotal Price: " + Price + "$");
             }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
