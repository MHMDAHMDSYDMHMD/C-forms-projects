﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ComboBoxValue = comboBox1.SelectedItem.ToString();
            if (ComboBoxValue == "Bread")
            {
                checkedListBox1.Items.Clear();
                checkedListBox1.Items.Add("Toast");
                checkedListBox1.Items.Add("Baguette");
            } if (ComboBoxValue == "Rice")
            {
                checkedListBox1.Items.Clear();
                checkedListBox1.Items.Add("Brown");
                checkedListBox1.Items.Add("Black");
            } if (ComboBoxValue == "Milk")
            {
                checkedListBox1.Items.Clear();
                checkedListBox1.Items.Add("Low-fat");
                checkedListBox1.Items.Add("Organic");
            } if (ComboBoxValue == "Beans")
            {
                checkedListBox1.Items.Clear();
                checkedListBox1.Items.Add("Green Beans");
                checkedListBox1.Items.Add("Kidney Beans");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double Total_Price = 0;
            string ClientName = textBox1.Text;
            string Product_Name = comboBox1.Text;
            string Prodcut_Type = checkedListBox1.Text;
            int NumberOfItems = checkedListBox1.CheckedItems.Count;
            if (ClientName == null || ClientName == "" || ClientName == " " || Product_Name == null || Product_Name == "" || Product_Name == " " || Prodcut_Type == null || Prodcut_Type == "" || Prodcut_Type == " ")
            {
                MessageBox.Show("Please check your data!");
                }else{
                    dataGridView1.Rows.Clear();
                for (int i = 0; i < NumberOfItems ; i++)
                {
                    Prodcut_Type = checkedListBox1.CheckedItems[i].ToString();
                    double Price1 = 0;
                    if (Prodcut_Type == "Toast" || Prodcut_Type == "Brown" || Prodcut_Type == "Low-fat" || Prodcut_Type == "Green Beans")
                    {
                        Price1 = 60;
                        Total_Price += Price1;
                    }
                     if (Prodcut_Type == "Baguette" || Prodcut_Type == "Black" || Prodcut_Type == "Organic" || Prodcut_Type == "Kidney Beans")
                    {
                        Price1 = 30;
                        Total_Price += Price1;
                    }

                    label6.Text = Total_Price.ToString();
                    dataGridView1.Rows.Add(ClientName, Product_Name, Prodcut_Type, Price1);
                    textBox1.Clear();
                }
        }
        }
    }
}
