﻿namespace ASSSSSSSSSSSSSS4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridViewDATA = new System.Windows.Forms.DataGridView();
            this.comboBoxproductname = new System.Windows.Forms.ComboBox();
            this.checkedListBoxproducttype = new System.Windows.Forms.CheckedListBox();
            this.btnaddbutton = new System.Windows.Forms.Button();
            this.lbltotalprice = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.ClientName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PorductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PorductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pricepro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDATA)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewDATA
            // 
            this.dataGridViewDATA.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewDATA.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridViewDATA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridViewDATA.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.MediumPurple;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewDATA.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewDATA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDATA.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClientName,
            this.PorductName,
            this.PorductType,
            this.pricepro});
            this.dataGridViewDATA.Location = new System.Drawing.Point(15, 231);
            this.dataGridViewDATA.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewDATA.Name = "dataGridViewDATA";
            this.dataGridViewDATA.Size = new System.Drawing.Size(767, 157);
            this.dataGridViewDATA.TabIndex = 13;
            // 
            // comboBoxproductname
            // 
            this.comboBoxproductname.FormattingEnabled = true;
            this.comboBoxproductname.Items.AddRange(new object[] {
            "rice ",
            "milk",
            "beans",
            "braed"});
            this.comboBoxproductname.Location = new System.Drawing.Point(131, 119);
            this.comboBoxproductname.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxproductname.Name = "comboBoxproductname";
            this.comboBoxproductname.Size = new System.Drawing.Size(179, 28);
            this.comboBoxproductname.TabIndex = 12;
            this.comboBoxproductname.SelectedIndexChanged += new System.EventHandler(this.comboBoxproductname_SelectedIndexChanged);
            // 
            // checkedListBoxproducttype
            // 
            this.checkedListBoxproducttype.FormattingEnabled = true;
            this.checkedListBoxproducttype.Items.AddRange(new object[] {
            "Toast",
            "Baguette"});
            this.checkedListBoxproducttype.Location = new System.Drawing.Point(541, 73);
            this.checkedListBoxproducttype.Margin = new System.Windows.Forms.Padding(4);
            this.checkedListBoxproducttype.Name = "checkedListBoxproducttype";
            this.checkedListBoxproducttype.Size = new System.Drawing.Size(254, 46);
            this.checkedListBoxproducttype.TabIndex = 11;
            // 
            // btnaddbutton
            // 
            this.btnaddbutton.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnaddbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnaddbutton.Location = new System.Drawing.Point(608, 127);
            this.btnaddbutton.Margin = new System.Windows.Forms.Padding(4);
            this.btnaddbutton.Name = "btnaddbutton";
            this.btnaddbutton.Size = new System.Drawing.Size(188, 50);
            this.btnaddbutton.TabIndex = 10;
            this.btnaddbutton.Text = "ADD";
            this.btnaddbutton.UseVisualStyleBackColor = false;
            this.btnaddbutton.Click += new System.EventHandler(this.btnaddbutton_Click);
            // 
            // lbltotalprice
            // 
            this.lbltotalprice.AutoSize = true;
            this.lbltotalprice.Location = new System.Drawing.Point(637, 195);
            this.lbltotalprice.Name = "lbltotalprice";
            this.lbltotalprice.Size = new System.Drawing.Size(0, 20);
            this.lbltotalprice.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(314, 26);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 27);
            this.label4.TabIndex = 18;
            this.label4.Text = "Super Maerket";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label3.Location = new System.Drawing.Point(424, 78);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 20);
            this.label3.TabIndex = 17;
            this.label3.Text = "product type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Location = new System.Drawing.Point(11, 119);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 20);
            this.label2.TabIndex = 16;
            this.label2.Text = "product name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Location = new System.Drawing.Point(11, 89);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 20);
            this.label1.TabIndex = 15;
            this.label1.Text = "client name";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(133, 89);
            this.txtname.Margin = new System.Windows.Forms.Padding(4);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(177, 26);
            this.txtname.TabIndex = 14;
            // 
            // ClientName
            // 
            this.ClientName.HeaderText = "Client Name";
            this.ClientName.Name = "ClientName";
            // 
            // PorductName
            // 
            this.PorductName.HeaderText = "Porduct Name";
            this.PorductName.Name = "PorductName";
            // 
            // PorductType
            // 
            this.PorductType.HeaderText = "Porduct Type";
            this.PorductType.Name = "PorductType";
            // 
            // pricepro
            // 
            this.pricepro.HeaderText = "price";
            this.pricepro.Name = "pricepro";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 401);
            this.Controls.Add(this.dataGridViewDATA);
            this.Controls.Add(this.comboBoxproductname);
            this.Controls.Add(this.checkedListBoxproducttype);
            this.Controls.Add(this.btnaddbutton);
            this.Controls.Add(this.lbltotalprice);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtname);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDATA)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewDATA;
        private System.Windows.Forms.ComboBox comboBoxproductname;
        private System.Windows.Forms.CheckedListBox checkedListBoxproducttype;
        private System.Windows.Forms.Button btnaddbutton;
        private System.Windows.Forms.Label lbltotalprice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClientName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PorductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PorductType;
        private System.Windows.Forms.DataGridViewTextBoxColumn pricepro;
    }
}

