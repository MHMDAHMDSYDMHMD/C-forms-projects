﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ASSSSSSSSSSSSSS4
{
    public partial class Form1 : Form
    {
        int price = 0;
        int totalprice = 0;

        public Form1()
        {
            InitializeComponent();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnaddbutton_Click(object sender, EventArgs e)
        {



            if (txtname.Text == null || comboBoxproductname.SelectedItem.ToString() == null || txtname.Text == "" || comboBoxproductname.SelectedItem.ToString() == "" || checkedListBoxproducttype.CheckedItems.Count < 0)
            {
                MessageBox.Show("please select all items");
            }
            else
            {
                string producttype = "";
                int numofdatadridveiwrows = dataGridViewDATA.Rows.Count;
                string strtxtname = txtname.Text;
                string strcombobox = comboBoxproductname.SelectedItem.ToString();
                int numchecklistbox = checkedListBoxproducttype.CheckedItems.Count;

              
               
                for (int y = 0; y < numchecklistbox; y++)
                {
                    producttype = checkedListBoxproducttype.CheckedItems[y].ToString();
                    dataGridViewDATA.Rows.Add(strtxtname, strcombobox, producttype, price.ToString());
                    totalprice += price;

                }
                lbltotalprice.Text = totalprice.ToString();

                
            }
        }
        
        private void comboBoxproductname_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strcombobox = comboBoxproductname.SelectedItem.ToString();
            if (strcombobox == "braed")
            {
                price = 100;
                checkedListBoxproducttype.Items.Clear();
                string[] strcomboboxietms = { "Toast", "Baguette" };
                checkedListBoxproducttype.Items.AddRange(strcomboboxietms);
            }

            else if (strcombobox == "milk")
            {
                price = 150;
                checkedListBoxproducttype.Items.Clear();

                string[] strcomboboxietms = { "low", "org" };
                checkedListBoxproducttype.Items.AddRange(strcomboboxietms);
            }

            else if (strcombobox == "beans")
            {
                price = 200;
                checkedListBoxproducttype.Items.Clear();

                string[] strcomboboxietms = { "green", "kidiny" };
                checkedListBoxproducttype.Items.AddRange(strcomboboxietms);
            }
            else 
            {
                price = 250;
                checkedListBoxproducttype.Items.Clear();

                string[] strcomboboxietms = { "brw", "blk" };
                checkedListBoxproducttype.Items.AddRange(strcomboboxietms);
            }
        }
    }
}
