﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            checkedListBox1.Items.Clear();
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string SelectItem = comboBox1.Text;
            if (SelectItem == "Pizza")
            {
                checkedListBox1.Items.Clear();
                checkedListBox1.Items.Add("Large");
                checkedListBox1.Items.Add("Medium");
                checkedListBox1.Items.Add("Small");
            }
            if (SelectItem == "Crep")
            {
                checkedListBox1.Items.Clear();
                checkedListBox1.Items.Add("Large");
                checkedListBox1.Items.Add("Medium");
                checkedListBox1.Items.Add("Small");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double Price = 0;
            double Total_Price = 0;
            string name = textBox1.Text.Trim();
            string Favourite_Food = textBox2.Text.Trim();
            string phone_number = textBox3.Text.Trim();
            string Main_Item = comboBox1.Text;
            int SelectedItems = checkedListBox1.CheckedItems.Count;
            string Sub_Item = "";
            if (name == null || name == "" || Favourite_Food == null || Favourite_Food == "" || phone_number == null || phone_number == "")
            {
                MessageBox.Show("Please check your data!");
            }
            else
            {
                dataGridView1.Rows.Clear();
                richTextBox1.Clear();
                for (int i = 0; i < SelectedItems; i++)
                {
                    if (checkedListBox1.CheckedItems[i] == "Large")
                    {
                        Price = 150;
                        Total_Price += Price;
                    }
                   else if (checkedListBox1.CheckedItems[i] == "Medium")
                    {
                        Price = 100;
                        Total_Price += Price;
                    }
                    if (checkedListBox1.CheckedItems[i] == "Small")
                    {
                        Price = 50;
                        Total_Price += Price;
                    }
                    Sub_Item = checkedListBox1.CheckedItems[i].ToString();
                    dataGridView1.Rows.Add(Main_Item, Sub_Item,Price);
                }

            /////////////////////////////////////////////////////////////
                string Data = "Name: "+name+"\nFavourite Food: "+ Favourite_Food+"\nPhone: "+phone_number+"\nTotal Price: "+Total_Price+"\n------------------------------------------";
                richTextBox1.AppendText(Data);
            }
        }
    }
}
