﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void USA_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            comboBox1.Items.Remove(comboBox1.SelectedItem);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ListBox.Items.Remove(ListBox.Text);

        }
        private void button3_Click(object sender, EventArgs e)
        {
            label3.Text = ListBox.SelectedItem.ToString();
            label4.Text = comboBox1.SelectedItem.ToString();
            label5.Text = checkBox1.Text;
            label5.Text = checkBox2.Text;
            label6.Text = radioButton1.Text;
            label6.Text = radioButton2.Text;

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void ListBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            label3.Text = ListBox.SelectedItem.ToString();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        private void label5_Click(object sender, EventArgs e)
        {

        }
        private void label6_Click(object sender, EventArgs e)
        {

        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
