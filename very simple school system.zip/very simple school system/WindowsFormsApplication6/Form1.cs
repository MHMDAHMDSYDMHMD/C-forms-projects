﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (
                   txtFirstName == null
                || txtFirstName.Text == ""
                || txtLastName == null
                || txtLastName.Text == ""
                || txtaddress == null
                || txtaddress.Text == ""
                || txteng == null
                || txteng.Text == ""
                || txtmath == null
                || txtmath.Text == ""
                || txtit == null
                || txtit.Text == ""
              )
            {
                MessageBox.Show("please write all data");
            }
            else
            {
                string strfname = txtFirstName.Text;
                string strlname = txtLastName.Text;
                string straddress = txtaddress.Text;
                int streng = Convert.ToInt32(txteng.Text);
                int  strnmath = Convert.ToInt32(txtmath.Text);
                int  strit = Convert.ToInt32(txtit.Text);
                int strbouns = Convert.ToInt32(txtbouns.Text);
                int totalgrade = strnmath + strit +  streng +  strbouns;
                dataGridView1.Rows.Add(strfname, strlname, straddress, streng, strnmath, strit, strbouns ,totalgrade);
            }
        
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            if (
            txtFirstName.Text != dataGridView1.SelectedRows[0].Cells[0].Value.ToString()
          || txtLastName.Text != dataGridView1.SelectedRows[0].Cells[1].Value.ToString()
          || txtaddress.Text != dataGridView1.SelectedRows[0].Cells[2].Value.ToString()
          || txteng.Text != dataGridView1.SelectedRows[0].Cells[3].Value.ToString()
          || txtmath.Text != dataGridView1.SelectedRows[0].Cells[4].Value.ToString()
          || txtit.Text != dataGridView1.SelectedRows[0].Cells[5].Value.ToString()
          || txtbouns.Text != dataGridView1.SelectedRows[0].Cells[6].Value.ToString()
          )
            {
                dataGridView1.SelectedRows[0].Cells[0].Value = txtFirstName.Text;
                dataGridView1.SelectedRows[0].Cells[1].Value = txtLastName.Text;
                dataGridView1.SelectedRows[0].Cells[2].Value = txtaddress.Text;
                dataGridView1.SelectedRows[0].Cells[3].Value = txteng.Text;
                dataGridView1.SelectedRows[0].Cells[4].Value = txtmath.Text;
                dataGridView1.SelectedRows[0].Cells[5].Value = txtit.Text;
                dataGridView1.SelectedRows[0].Cells[6].Value = txtbouns.Text;
            }
            txtFirstName.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            txtLastName.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            txtaddress.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            txteng.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            txtmath.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            txtit.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            txtbouns.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
      
            }

        private void btndelete_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
            int NumberOfSelectRow = dataGridView1.SelectedRows.Count;
            if (NumberOfSelectRow > 0)
            {
                foreach (DataGridViewRow Row in dataGridView1.SelectedRows)
                {
                    //1st Way
                    //dataGridView1.Rows.RemoveAt(Row.Index);
                    //2nd Way
                    dataGridView1.Rows.Remove(Row);
                }
            }
        }
    }
}
