﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox2.Items.Add("L");
            comboBox2.Items.Add("M");
            comboBox2.Items.Add("S");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (
                comboBox1.SelectedItem == ""
                || comboBox2.SelectedItem == ""
                || numericUpDown1.Value == null
                || numericUpDown1.Value == 0
                || (!radioButton1.Checked
                && !radioButton2.Checked
                && !radioButton3.Checked)
               )
            {
                MessageBox.Show("please select and write all items");
            }
            else
            { 
                string rb  = "";
            if(radioButton1.Checked){rb = radioButton1.Text;}
            else if (radioButton2.Checked) { rb = radioButton2.Text; }
            else if (radioButton3.Checked) { rb = radioButton3.Text; }
            decimal num = numericUpDown1.Value;
            string strname = comboBox1.SelectedItem.ToString();
            string strvolume = comboBox2.SelectedItem.ToString();
            string data = strname + "\n " + strvolume + "\n " + num + "\n " + rb;
            listBox1.Items.Add(data);


            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (
                comboBox1.SelectedItem == ""
                || comboBox2.SelectedItem == ""
                || numericUpDown1.Value == null
                || numericUpDown1.Value == 0
                || (!radioButton1.Checked
                && !radioButton2.Checked
                && !radioButton3.Checked)
               )
            { MessageBox.Show("please select and write all items"); }
            else
            {
                string rb = "";
                if (radioButton1.Checked) { rb = radioButton1.Text; }
                else if (radioButton2.Checked) { rb = radioButton2.Text; }
                else if (radioButton3.Checked) { rb = radioButton3.Text; }
                decimal num = numericUpDown1.Value;
                string strname = comboBox1.SelectedItem.ToString();
                string strnamvolume = comboBox2.SelectedItem.ToString();

                SqlConnection scon = new SqlConnection(@"Data Source=DESKTOP-32SOVCV-LAP\SQLEXPRESS;Initial Catalog=Store;Integrated Security=True");
                scon.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = scon;
                cmd.CommandText = "insert into Shirt values(@Name, @Quantity, @Color)";
                cmd.Parameters.AddWithValue("@Name", strname);
                cmd.Parameters.AddWithValue("@Quantity", num);
                cmd.Parameters.AddWithValue("@Color", rb);
                cmd.ExecuteNonQuery();
                scon.Close();
                MessageBox.Show("Data Inserted Successfully.");


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection scon = new SqlConnection(@"Data Source=DESKTOP-32SOVCV-LAP\SQLEXPRESS;Initial Catalog=Store;Integrated Security=True");
            scon.Open();
            SqlCommand cmd2 = new SqlCommand("select * from Shirt", scon);
            int i = cmd2.ExecuteNonQuery();
            int totalprice = 50 * i;
            scon.Close();
            MessageBox.Show(Convert.ToString(totalprice));
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }
    }
}
